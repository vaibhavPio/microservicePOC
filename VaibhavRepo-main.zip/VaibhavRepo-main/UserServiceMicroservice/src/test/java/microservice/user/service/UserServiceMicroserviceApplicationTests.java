package microservice.user.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
